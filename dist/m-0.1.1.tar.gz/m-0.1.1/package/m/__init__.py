print('+++++++++',__name__)

def _f():pass
__MY__ = 'm2.MY'

def g():
    print('g')