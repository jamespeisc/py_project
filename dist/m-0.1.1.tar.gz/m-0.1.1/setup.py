from distutils.core import setup

setup(name='m',
      version='0.1.1',
      description='magedu m module',
      author='wayne',
      author_email='wayne@magedu.com',
      url='http://www.magedu.com',
      packages=['package/m'],
      )